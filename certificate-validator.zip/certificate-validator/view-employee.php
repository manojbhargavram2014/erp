<!doctype html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CMRTC - View Employee</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <style type="text/css">
    </style>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <?php include 'header.php'; 

    ?>
	<pre>
	</pre>
<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" v-if="headerText"><center>Employee Details</center></strong>
                            </div>
                            <div class="card-body p-0">
                                <table class="table table-hover table-striped table-align-middle mb-0">
                                  <?php
							  if(isset($_GET['emp_id']))
							  {
								  $emp_id=$_GET['emp_id'];
							$query=mysqli_query($con,"select * from emp_data where emp_id='$emp_id'");
							while($list=mysqli_fetch_assoc($query))
							{
								?> 
								<style>
								td{ 
								text-align: center;
								}
								</style>
                                    <tbody>
										<tr>
                                            <td>
                                                Employee Picture
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="lg" :checked="true"/>
                                            </td>
                                            <td>
												<img src="upload/<?php echo $list['img'] ?>" width="300px">
                                                
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Employee ID
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="lg" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['emp_id'] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               Name
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" :checked="true"/>
                                            </td>
                                            <td>
												<?php echo $list['name'] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               Date Of Birth
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="sm" :checked="true"/>
                                            </td>
                                            <td>
												<?php echo $list['dob'] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Gender
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['gender'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Educational Details
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['edudetails'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Experience
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['experience'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Duration
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['duration'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                               Employee Type
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['emptype'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Stipend / Salary
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['salary'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Email Id
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['email'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Mobile Number
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['phno'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Address
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['address'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Feedback or suggestions
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['feedback'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Issue Date
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['issue_date'] ?>
                                            </td>
                                        </tr>
										<tr>
                                            <td>
                                                Valid Till
                                            </td>
                                            <td>
                                                <basix-switch type="3d" variant="primary" size="xs" :checked="true"/>
                                            </td>
                                            <td>
                                                <?php echo $list['valid_till'] ?>
                                            </td>
                                        </tr>
                                    </tbody>
									<?php }}  ?>
                                </table>
                            </div>
                        </div>
                    </div><!--/.col-->
<?php include 'footer.php'; ?>